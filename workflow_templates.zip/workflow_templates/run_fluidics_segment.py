#!/usr/bin/env python3
"""
run_fluidics_segment.py — run one fluidics segment for the Squid Workflow Runner.

WHY THIS EXISTS
    The GUI Fluidics tab runs a single reagent sequence that contains exactly
    ONE "Imaging" step (control/fluidics.py splits the sequence into
    before-imaging / after-imaging around that one point, and rejects a file
    with more than one "Imaging" row). A protocol with TWO or more imaging steps
    cannot be expressed there.

    The Workflow Runner solves this differently: it runs an ordered list of steps
    (script, acquisition, script, acquisition, ...), cycled N times. So instead of
    one sequence with embedded "Imaging" markers, split the reagent protocol into
    SEGMENTS at each imaging point and let the Workflow Runner interleave the
    acquisitions:

        Segment 1  ->  Acquisition  ->  Segment 2  ->  Acquisition  ->  Segment 3

    This script runs ONE such segment. It is a thin wrapper around the fluidics_v2
    module (the same code control/fluidics.py drives), so it works with or without
    hardware via --simulation. Each segment CSV uses the same columns the Fluidics
    tab uses, minus any "Imaging" row.

    The config JSON path is normally set ONCE via DEFAULT_CONFIG_PATH below, so it
    does not need to be passed on every run. --config overrides it when needed.

USAGE (standalone, for testing)
    python3 run_fluidics_segment.py --sequence segment_1_before_imaging.csv --simulation

    # Override the probe port for this run (see --probe-label below):
    python3 run_fluidics_segment.py --sequence segment_1_before_imaging.csv --simulation --port 3

USAGE (from the Workflow Runner)
    Add a "script" step whose arguments are, e.g.:
        --sequence workflow_templates/segment_1_before_imaging.csv --simulation
    and set the step's cycle argument name to "port" with one value per cycle
    (e.g. "1,3,5,7"). The Workflow Runner then appends "--port <value>" each cycle,
    which this script uses to override the probe port. See workflow_template.yaml.

EXIT CODE
    0 on success, non-zero if any sequence step reports an error. The Workflow
    Runner treats a non-zero exit as a failed step.
"""

import argparse
import json
import os
import sys
import threading


# Path to the fluidics_v2 python package (the folder that contains the "fluidics"
# package). Default assumes the Workflow Runner launches with the Squid "software/"
# directory as the working directory, exactly like control/fluidics.py does.
# Override with --fluidics-path if you keep this template elsewhere.
DEFAULT_FLUIDICS_PATH = "fluidics_v2/software"

# Path to the fluidics config JSON — the SAME file the GUI Fluidics tab uses.
# This rarely changes per machine, so set it ONCE here and leave --config out of the
# Workflow Runner step arguments. Passing --config still overrides this default.
# An absolute path is recommended (the Workflow Runner's working directory is the
# Squid "software/" folder).
DEFAULT_CONFIG_PATH = "../merfish_config/fluidics_config.json"  # TODO: set to your real config path


def parse_args():
    parser = argparse.ArgumentParser(description="Run one fluidics segment for the Squid Workflow Runner.")
    parser.add_argument("--sequence", required=True, help="Path to the segment CSV file (no 'Imaging' row).")
    parser.add_argument(
        "--config",
        default=DEFAULT_CONFIG_PATH,
        help=f"Path to the fluidics config JSON file (default: {DEFAULT_CONFIG_PATH!r}, "
        "normally set once via DEFAULT_CONFIG_PATH at the top of this file).",
    )
    parser.add_argument(
        "--simulation", action="store_true", default=False, help="Run without hardware (simulated pump/valves)."
    )
    parser.add_argument(
        "--port",
        type=int,
        default=None,
        help="Override the fluidic_port of every row whose sequence_name matches --probe-label. "
        "Supplied per-cycle by the Workflow Runner; leave unset to use the ports in the CSV.",
    )
    parser.add_argument(
        "--probe-label",
        default="probe",
        help="Case-insensitive substring identifying which rows --port overrides (default: 'probe').",
    )
    parser.add_argument(
        "--fluidics-path",
        default=DEFAULT_FLUIDICS_PATH,
        help=f"Path to the fluidics_v2 python package (default: {DEFAULT_FLUIDICS_PATH!r}, relative to CWD).",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    # Make the fluidics_v2 package importable before importing from it.
    fluidics_path = os.path.abspath(args.fluidics_path)
    if not os.path.isdir(os.path.join(fluidics_path, "fluidics")):
        print(
            f"Error: fluidics package not found under {fluidics_path!r}. "
            f"Pass --fluidics-path pointing at the folder that contains the 'fluidics' package.",
            file=sys.stderr,
        )
        sys.exit(2)
    sys.path.insert(0, fluidics_path)

    import pandas as pd
    from fluidics.control.controller import FluidControllerSimulation, FluidController
    from fluidics.control.syringe_pump import SyringePumpSimulation, SyringePump
    from fluidics.control.selector_valve import SelectorValveSystem
    from fluidics.merfish_operations import MERFISHOperations
    from fluidics.experiment_worker import ExperimentWorker
    from fluidics.control._def import CMD_SET

    # --- Load config (JSON) -----------------------------------------------------------
    if not os.path.isfile(args.config):
        print(
            f"Error: fluidics config not found at {args.config!r}. "
            f"Set DEFAULT_CONFIG_PATH at the top of this script to your config JSON "
            f"(the same file the GUI Fluidics tab uses), or pass --config.",
            file=sys.stderr,
        )
        sys.exit(2)
    with open(args.config, "r") as f:
        config = json.load(f)
    if config.get("application") != "MERFISH":
        print(
            f"Error: this template supports the 'MERFISH' (flow cell) application only, but the config "
            f"declares application={config.get('application')!r}.",
            file=sys.stderr,
        )
        sys.exit(2)

    # --- Load and prepare the sequence (CSV) ------------------------------------------
    df = pd.read_csv(args.sequence)
    df = df[df["include"] == 1].reset_index(drop=True)

    if args.port is not None:
        mask = df["sequence_name"].str.contains(args.probe_label, case=False, na=False)
        n = int(mask.sum())
        if n == 0:
            print(
                f"Warning: --port {args.port} was given but no sequence_name contains "
                f"'{args.probe_label}'; no port was overridden.",
                flush=True,
            )
        else:
            df.loc[mask, "fluidic_port"] = args.port
            print(f"Overrode fluidic_port -> {args.port} on {n} row(s) matching '{args.probe_label}'.", flush=True)

    # --- Track failures via callbacks (ExperimentWorker never raises to the caller) ---
    failed = threading.Event()

    def on_error(msg):
        print(f"Error: {msg}", file=sys.stderr, flush=True)
        failed.set()

    callbacks = {
        "update_progress": lambda idx, seq_num, status: print(f"  row {idx} ({seq_num}): {status}", flush=True),
        "on_error": on_error,
        "on_finished": lambda: print("Segment finished.", flush=True),
        "on_estimate": lambda t, n: print(f"Estimated time: {t:.0f}s across {n} step(s).", flush=True),
    }

    syringe_pump = None
    try:
        controller_cls = FluidControllerSimulation if args.simulation else FluidController
        pump_cls = SyringePumpSimulation if args.simulation else SyringePump

        controller = controller_cls(config["microcontroller"]["serial_number"])
        syringe_pump = pump_cls(
            sn=config["syringe_pump"]["serial_number"],
            syringe_ul=config["syringe_pump"]["volume_ul"],
            speed_code_limit=config["syringe_pump"]["speed_code_limit"],
            waste_port=config["syringe_pump"].get("waste_port", 3),
        )

        controller.begin()
        controller.send_command(CMD_SET.CLEAR)

        selector_valve_system = SelectorValveSystem(controller, config)
        experiment_ops = MERFISHOperations(config, syringe_pump, selector_valve_system)

        worker = ExperimentWorker(experiment_ops, df, config, callbacks)
        thread = threading.Thread(target=worker.run)
        thread.start()
        thread.join()

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr, flush=True)
        failed.set()
    finally:
        if syringe_pump is not None:
            syringe_pump.reset_abort()
            syringe_pump.close()

    if failed.is_set():
        sys.exit(1)


if __name__ == "__main__":
    main()
