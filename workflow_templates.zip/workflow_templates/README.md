# Multi-imaging fluidics via the Workflow Runner

These templates run a fluidics protocol that has **two imaging steps** — something
the GUI **Fluidics tab cannot do** (it requires exactly one `Imaging` step per
sequence; `control/fluidics.py::_validate_sequences` raises *"Multiple 'Imaging'
sequences found"*). The Workflow Runner instead runs an ordered list of steps, so
we split the protocol into segments at each imaging point and let the runner
interleave the acquisitions.

These templates target the **fluidics_v2 commit pinned by this repo**
(`79c2914`), which uses the CSV-sequence + JSON-config API — the same one
`control/fluidics.py` drives. (A newer fluidics_v2 with a typed-YAML API exists
upstream, but it is not what this repo checks out.)

Original protocol (`multi_imaging_script.txt`) split at the two `Imaging` lines:

| Step in workflow | Fluidics file | Probe port (per cycle) |
|---|---|---|
| Segment 1 (before imaging 1) | `segment_1_before_imaging.csv` | overridden: `1,3,5,7` |
| **Acquisition 1** | — (GUI settings or a saved acquisition.yaml) | — |
| Segment 2 (between imagings) | `segment_2_between_imaging.csv` | overridden: `2,4,6,8` |
| **Acquisition 2** | — | — |
| Segment 3 (after imaging 2) | `segment_3_after_imaging.csv` | none |

## Files

- `run_fluidics_segment.py` — runs one segment; standalone-testable; `--simulation` supported.
- `segment_1_before_imaging.csv`, `segment_2_between_imaging.csv`, `segment_3_after_imaging.csv` — the split protocol. Same columns as the GUI Fluidics tab, minus the `Imaging` row. `incubation_time` is in **minutes**.
- `fluidics_config.json` — hardware/reagent config template (fill in serials + reagent names).
- `workflow_template.yaml` — load this in the Workflow Runner; wires the steps above with `num_cycles: 4`.

## Run it

1. Put this `workflow_templates/` folder inside the Squid `software/` directory (paths in the YAML are relative to it).
2. Edit `fluidics_config.json`: real serial numbers, and `reagent_name_mapping` so each port is the reagent actually plumbed to it.
3. Edit `workflow_template.yaml`: set `num_cycles` (3 or 4…) and the `cycle_arg_values` probe-port lists (one entry per cycle).
4. Set `DEFAULT_CONFIG_PATH` at the top of `run_fluidics_segment.py` to your real config JSON (the same file the GUI Fluidics tab uses).
5. Workflow tab → Load `workflow_template.yaml` → Run.

`workflow_template.yaml` is set for a **real (hardware) run** — no `--simulation`. For a hardware-free dry run, append ` --simulation` to the `arguments` of all three script steps.

Test a single segment without the GUI:

```bash
cd /path/to/Squid/software
python3 workflow_templates/run_fluidics_segment.py \
    --sequence workflow_templates/segment_1_before_imaging.csv \
    --config   workflow_templates/fluidics_config.json \
    --simulation --port 3
```

## How the probe port varies per cycle

The Workflow Runner appends `--<cycle_arg_name> <value>` to a script step once per
cycle, taking the value from `cycle_arg_values`. Here `cycle_arg_name: port`, so
each cycle appends `--port N`. `run_fluidics_segment.py` rewrites the `fluidic_port`
of every row whose **sequence_name contains "probe"** (case-insensitive) to that
value — buffers are left untouched. Segment 3 has no probe, so it takes no `--port`.

## Notes / things to double-check

- **Imaging buffer port differs between rounds** in the source file: segment 1 uses
  port 27, segment 2 uses port 24. Preserved as-is — confirm that's intentional.
- **Acquisition settings**: both acquisition steps use the current GUI settings.
  To pin per-round settings, uncomment `config_path:` in the workflow YAML and point
  it at a saved acquisition.yaml.
- **Timing in simulation**: incubation waits are real wall-clock (minutes), and the
  simulated syringe pump sleeps ~5 s per flow op, so a full simulated run of the real
  segments still takes many minutes — that's expected, not a hang. (For a quick dry
  run, temporarily set the `incubation_time` column to 0 in the CSVs.)
